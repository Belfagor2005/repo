# plugin.video.dplay
Kodi unofficial plugin for Dplay.
Help development by sending your pull request ;-)
